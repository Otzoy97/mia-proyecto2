import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  user = {
    name: '',
    surname: '',
    country: '',
    date: '',
    email: '',
    pwd: '',
    pwdRef: '',
    photo: ''
  }

  constructor() { }

  ngOnInit(): void {
  }

  signUp() : void {
    
  }
}
